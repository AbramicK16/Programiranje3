﻿using System;

namespace RazredVektor_izpit
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine ("Hello World!");
        }
    }
}
