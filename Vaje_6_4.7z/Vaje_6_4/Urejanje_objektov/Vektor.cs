﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Urejanje_objektov
{
    public class Vektor : IComparable<Vektor>
    {
        private int x;
        private int y;
        private int nastanek;
        private static int trenutni = 0;

        public int X
        {
            get { return this.x; }
            set { this.x = value; }
        }

        public int Y
        {
            get { return this.y; }
            set { this.y = value; }
        }

        public int Nastanek
        {
            get { return this.nastanek; }
        }
        public double Length
        {
            get { return Math.Pow ((Math.Pow (this.x, 2) + Math.Pow (this.y, 2)), 0.5); }

        }

        public override string ToString()
        {
            string niz = "[" + this.x.ToString () + ", " + this.y.ToString () + "]";
            return niz;
        }

        /// <summary>
        /// Konstruktor vektor
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        public Vektor(int a, int b)
        {
            this.x = a;
            this.y = b;
            this.nastanek = Vektor.trenutni;
            Vektor.trenutni = Vektor.trenutni + 1;
        }

        //nicelni vektor
        public Vektor()
        {
            this.X = 1;
            this.Y = 1;
            this.nastanek = Vektor.trenutni;
            Vektor.trenutni = Vektor.trenutni + 1;
        }
        //vsota dveh vektorjev
        public static Vektor operator +(Vektor v1, Vektor v2)
        {
            return new Vektor (v1.X + v2.X, v1.Y + v2.Y);
        }

        //razlika dveh vektorjev
        public static Vektor operator -(Vektor v1, Vektor v2)
        {
            return new Vektor (v1.X - v2.X, v1.Y - v2.Y);
        }

        /// <summary>
        /// Metodi za množenje vektorja s skalarjem (z leve in z desne strani)
        /// </summary>
        /// <param name="skalar"></param>
        /// <param name="v1"></param>
        /// <returns></returns>
        public static Vektor operator *(int skalar, Vektor v1)
        {
            return new Vektor (skalar * v1.X, skalar * v1.Y);
        }

        public static Vektor operator *(Vektor v1, int skalar)
        {
            return new Vektor (v1.X * skalar, v1.Y * skalar);
        }

        /// <summary>
        /// Skalarni produkt dveh vektorjev
        /// </summary>
        /// <param name="v1"></param>
        /// <param name="v2"></param>
        /// <returns></returns>
        public static int operator *(Vektor v1, Vektor v2)
        {
            return (v1.X * v2.X + v1.Y * v2.Y);
        }

        /// <summary>
        /// Računski operator za povečanje koordinat za 1 enoto
        /// </summary>
        /// <param name="v1"></param>
        /// <returns></returns>
        public static Vektor operator ++(Vektor v1)
        {
            return v1 + new Vektor (); //vektorju prištejemo vektor (1, 1)
        }

        /// <summary>
        /// Računski operator za zmanjšanje koordinat za 1 enoto
        /// </summary>
        /// <param name="v1"></param>
        /// <returns></returns>
        public static Vektor operator --(Vektor v1)
        {
            return v1 - new Vektor ();
        }
        /// <summary>
        /// Nasprotno usmerjen vektor
        /// </summary>
        public static Vektor operator -(Vektor v1)
        {
            return v1 - (v1 * 2);
        }

        public bool Equals(Vektor v2)
        {
            if (this.X == v2.X && this.Y == v2.Y) { return true; }
            return false;
        }

        public static bool operator <(Vektor v1, Vektor v2)
        {
            return (v1.Length < v2.Length); //primerjamo dolzini obeh vektorjev
        }

        public static bool operator >(Vektor v1, Vektor v2)
        {
            return (v1.Length > v2.Length);
        }

        public static bool operator <=(Vektor v1, Vektor v2)
        {
            return (v1.Length <= v2.Length);
        }

        public static bool operator >=(Vektor v1, Vektor v2)
        {
            return (v1.Length >= v2.Length);
        }

        public static bool operator ==(Vektor v1, Vektor v2)
        {
            return v1.Equals (v2);
        }

        public static bool operator !=(Vektor v1, Vektor v2)
        {
            return !v1.Equals (v2);
        }


        public static bool operator true(Vektor v1)
        {
            return (v1.X != 0 || v1.Y != 0);
        }

        public static bool operator false(Vektor v1)
        {
            return (v1.X != 0 && v1.Y != 0);
        }

        public static bool operator &(Vektor v1, Vektor v2)
        {
            if (v1)
            {
                if (v2)
                {
                    return true; // če sta oba true, vrnemo true
                }
            }
            return false; // če je vsaj en false, vrnemo false
        }

        public static bool operator |(Vektor v1, Vektor v2)
        {
            if (v1)
            {
                return true;
            }
            if (v2)
            {
                return true;
            }
            return false;
        }

        public static bool operator ^(Vektor v1, Vektor v2)
        {
            if (v1 & v2)
            {
                return false;
            }
            if (!(v1 | v2))
            {
                return false;
            }
            return true;
        }

        public static double operator ~(Vektor v1)
        {
            return v1.Length;
        }

        public int CompareTo(Vektor v2) // ce sta vektorja po dolzini enaka, ju primerjamo po casu nastanka.
        {
            double razlika = this.Length - v2.Length;
            if (razlika < 0)
            {
                return -1;
            }
            if (razlika > 0)
            {
                return 1;
            }
            return this.nastanek - v2.nastanek;
        }

        public static explicit operator float(Vektor v1)
        {
            return (float)v1.Length;
        }

        //#########################################################################################################
        public Vektor[] GenerirajTabeloVektorjev(int st_elementov)
        {
            Vektor[] tabela_vektorjev = new Vektor[st_elementov + 3];
            if (st_elementov < 1) throw new Exception ("Tabela mora imeti vsaj en element");

            Random rand = new Random ();
            for (int i = 0; i < st_elementov; i++)
            {
                int randX = rand.Next (-50, 50);
                int randY = rand.Next (-50, 50);
                tabela_vektorjev[i] = new Vektor (randX, randY);
            }
            return tabela_vektorjev;
        }

        public void Izpisi_v_tabelo(Vektor[] tabela_vektorjev)
        {
            for (int i = 0; i < (tabela_vektorjev.Length) - 3; i++)
            {
                Console.WriteLine (tabela_vektorjev[i]);
            }
        }


    }
}