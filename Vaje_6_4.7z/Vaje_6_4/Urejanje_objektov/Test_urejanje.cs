﻿using System;
using Urejanje_objektov;

namespace Urejanje_objektov
{
    class Test_urejanje
    {
        static void Main(string[] args)
        {
            Urejanje_objektov.Vektor[] tab = new Urejanje_objektov.Vektor[15]; //nakljucna tabela velikosti 15
            Urejanje_objektov.Vektor vektor = new Urejanje_objektov.Vektor ();
            Random rand = new Random ();
            int stevka;
            for (int i = 0; i < 12; i++)
            {
                stevka = rand.Next (15);
                tab[i] = vektor * stevka;
            }

            // Izpisemo objekte v tabeli (brez zadnjih treh neobstojecih)
            for (int i = 0; i < 12; i++)
            {
                Console.WriteLine (tab[i]);
            }

            // Vstavimo se 3 objekte, ki so kopija 3., 5. in ponovno 3. elementa tabele
            stevka = 12;
            tab[stevka] = tab[2] * 1; //13 element je enak tretjemu v tabeli
            stevka++;
            tab[stevka] = tab[4] * 1; //14 element je enak petemu v tabeli
            stevka++;
            tab[stevka] = tab[2] * 1; //15 element je enak tretjemu v tabeli

            // Tabelo uredimo
            Array.Sort (tab);

            // Ponovno izpisemo sedaj urejeno tabelo
            Console.WriteLine ("Urejena tabela:");
            for (int i = 0; i < 15; i++)
            {
                Console.WriteLine (tab[i]);

            }
        }
    }
}
