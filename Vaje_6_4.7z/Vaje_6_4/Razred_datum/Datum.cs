﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Razred_datum
{
    class Datum
    {
    }
}
