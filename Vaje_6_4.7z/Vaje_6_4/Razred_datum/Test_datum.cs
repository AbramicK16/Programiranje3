﻿using System;

namespace Razred_datum
{
    class Test_datum
    {
        static void Main(string[] args)
        {
            Console.WriteLine ("Hello World!");
        }
    }
}
