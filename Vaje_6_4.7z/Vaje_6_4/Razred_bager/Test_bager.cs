﻿using System;
using System.IO;

namespace Razred_bager
{
    class Test_bager
    {
        static void Main(string[] args)
        {
            Console.WriteLine ();
            string ime = "nova.txt";
            if (File.Exists (ime))
            {
                File.Delete (ime);
            }
            Bager.TvoriDatoteke (ime, 10);
            Console.WriteLine ("Datoteka nakljucnih bagrov: ");
            Bager.IzpisiDatoteko (ime);
            Console.WriteLine ();
            Bager[] tabela = Bager.PreberiZDatoteke (ime);
            Bager.IzpisiTabelo (tabela);
            Console.WriteLine ();
            Bager[] tabela2 = Bager.Odstrani (tabela);
            Console.WriteLine ();
            Console.WriteLine ("Bagri mlajši od 12 let: ");
            Bager.IzpisiTabelo (tabela2);
            Console.WriteLine ();
            //Bager[] tab = Bager.Poceni(tabela);

            Bager.Prepisi (ime);

        }
    }
}
