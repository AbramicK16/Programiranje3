﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Data;

namespace Razred_bager
{
    public class Bager
    {
        private int teza;
        private string ime;
        private int leto_izdelave;
        private int cena;

        /// <summary>
        /// Lastnost za branje / spreminjanje cene
        /// </summary>
        public int Cena
        {
            get { return this.cena; }
            set
            {
                if (value <= 0) throw new Exception ("Cena mora biti pozitivna! ");
                this.cena = value;
            }
        }

        /// <summary>
        /// Lastnost samo za branje leta izdelave
        /// </summary>
        public int Leto
        {
            get { return this.leto_izdelave; }
        }


        /// <summary>
        /// Lastnost za tezo
        /// </summary>
        public int Teza
        {
            get { return this.teza; }
        }

        /// <summary>
        /// Prazen konstruktor
        /// </summary>
        public Bager()
        {
            this.teza = 8000;
            this.ime = "Drejc";
            this.leto_izdelave = 2003;
            this.cena = 50000;
        }

        /// <summary>
        /// Konstruktor
        /// </summary>
        /// <param name="tezaB">teza bagra v kg</param>
        /// <param name="imeB">naziv bagra</param>
        /// <param name="letoB">leto izdevale</param>
        /// <param name="cenaB">cena v EUR</param>
        public Bager(int tezaB, string imeB, int letoB, int cenaB)
        {
            if (tezaB < 0) throw new Exception ("Teža mora biti pozitivna!");
            this.teza = tezaB;

            this.ime = imeB;

            if (letoB < 1990 && letoB > 2020) throw new Exception ("Leto mora biti med 1990 in 2020!");
            this.leto_izdelave = letoB;

            this.cena = cenaB;
        }

        /// <summary>
        /// Polni konstruktor
        /// </summary>
        /// <param name="niz"></param>
        public Bager(string niz)
        {
            string[] tabela = niz.Split (); 
            if (tabela.Length != 8) throw new Exception ("Niz ne ustreza opisu kolesa."); //v vsaki vrstici bo 8 elementov, ker je 8 besedv nizu ki predstavlja bager

            int tezaB = int.Parse (tabela[3]); 
            if (tezaB < 0) throw new Exception ("Teža mora biti pozitivna!");
            this.teza = tezaB;

            this.ime = tabela[1];
           
            int letoB = 2018;

            if (letoB < 1990 && letoB > 2020) throw new Exception ("Leto mora biti med 1990 in 2020!");
            this.leto_izdelave = letoB;

            int cenaB = int.Parse (tabela[6]); //cena je 6.podatek
            this.cena = cenaB;
        }


        public override string ToString()
        {
            string niz = "Bager " + this.ime + " težak " + this.teza + " kg stane " + this.cena + " EUR.";
            return niz;
        }

        /*public override string ToString()
        {
            string niz = this.teza + ";" + this.ime + ";" + this.leto_izdelave + ";" + this.cena;
            return niz;
        }*/


        /// <summary>
        /// Metoda Dodaj na Datoteko objekt this zapiše kot vrstico this.ToString() na 
        /// odprto tekstovno datoteko
        /// </summary>
        /// <param name="dat">ime datoteke</param>
        public void DodajNaDatoteko(string dat)
        {
            StreamWriter datoteka;
            if (File.Exists (dat)) //ce datoteka ze obstaja
            {
                datoteka = File.AppendText (dat); //na datoteko dodamo objekt
            }
            else //ce datoteka ne obstaja
            {
                datoteka = File.CreateText (dat); //na datoteko zapisemo objekt
            }
            datoteka.WriteLine (this.ToString ());
            datoteka.Close ();

        }

        /// <summary>
        /// Metoda vrne tabelo objektov, kjer posamezni objekt vsebuje
        /// podatke, ki so zapisani v posamezni vrstici tekstovne datoteke
        /// </summary>
        /// <param name="imeDatoteke"></param>
        /// <returns></returns>
        public static Bager[] PreberiZDatoteke(string imeDatoteke)
        {
            string[] tabela = File.ReadAllLines (imeDatoteke);

            Bager[] tabelaBagrov = new Bager[tabela.Length];
            for (int i = 0; i < tabela.Length; i++)
            {
                Bager trenutni = new Bager (tabela[i]);
                tabelaBagrov[i] = trenutni;
            }
            return tabelaBagrov;
        }

        /// <summary>
        /// Metoda izpiše predstavitev objektov, katerih podatki so v 
        /// posamezni vrstici
        /// </summary>
        /// <param name="imeDatoteke"></param>
        public static void IzpisiDatoteko(string imeDatoteke)
        {
            StreamReader datoteka = File.OpenText (imeDatoteke);
            string vrstica = "";
            while (vrstica != null) //gremo cez celo vrstico
            {
                vrstica = datoteka.ReadLine ();
                Console.WriteLine (vrstica);
            }
        }

        public static void IzpisiTabelo(Bager[] tabelaBagrov)
        {
            foreach (Bager bager in tabelaBagrov)
            {
                Console.WriteLine (bager);
            }
        }


        /// <summary>
        /// Tvori stevilo objektov, ki jih zapise na datoteko
        /// </summary>
        /// <param name="imeDatoteke"></param>
        /// <param name="stElementov"></param>
        public static void TvoriDatoteke(string imeDatoteke, int stElementov)
        {
            string[] sezImen = new string[] { "Drejc", "Yanmar", "Takeuchi", "Wacker", "Bobcat", "Neuson" };
            int tezaBagra;
            string imeBagra;
            int leto;
            int cenaBagra;

            Random genTeza = new Random ();
            Random genIme = new Random ();
            Random genLeto = new Random ();
            Random genCena = new Random ();

            Bager trenutni = new Bager ();
            for (int i = 0; i < stElementov; i++)
            {
                tezaBagra = genTeza.Next (2500, 10000);
                imeBagra = sezImen[genIme.Next (1, 6)];
                leto = genLeto.Next (1990, 2020);
                cenaBagra = genCena.Next (10000, 50000);

                trenutni = new Bager (tezaBagra, imeBagra, leto, cenaBagra);
                trenutni.DodajNaDatoteko (imeDatoteke);
            }
        }

        /// <summary>
        /// Izpiše najtezji bager
        /// </summary>
        /// <param name="tabelaBagrov"></param>
        public Bager Najtezji(Bager[] tabelaBagrov)
        {
            int najtezji = 0;
            Bager najBager = tabelaBagrov[0];
            foreach (Bager bager in tabelaBagrov)
            {
                if (bager.Teza > najtezji)
                {
                    najtezji = bager.teza;
                    najBager = bager;
                }
            }
            return najBager;
        }

        /// <summary>
        /// Vse bagre, ki so drazji od 20000, poceni za 10%
        /// </summary>
        /// <param name="tabelaBagrov"></param>
        public static void Poceni(Bager[] tabelaBagrov)
        {
            foreach (Bager bager in tabelaBagrov)
            {
                if (bager.cena > 20000)
                {
                    int novaCena = (bager.cena * 10) / 100;
                }
            }
        }

        /// <summary>
        /// Uredi tabelo bagrov po starosti. Če sta dva bagra iste letnice, 
        /// je prej tisti, ki je lažji.
        /// </summary>
        /// <param name="tabelaBagrov"></param>
        public int CompareTo(Bager drugi
            )
        {
            if (this.Leto < drugi.Leto)
            {
                return -1;
            }
            if (this.Leto > drugi.Leto)
            {
                return 1;
            }

            if (this.Teza < drugi.Teza)
            {
                return -1;
            }
            return 1;
        }

        /// <summary>
        /// Ostranite iz tabele vse bagre, ki so starejši od 12 let.
        /// </summary>
        /// <param name="tabelaBagrov"></param>
        /// <returns></returns>

        public static Bager[] Odstrani(Bager[] tabelaBagrov)
        {
            int koliko = 0;
            int mlajsi = DateTime.Now.Year - 12; //trenutno leto
            foreach (Bager bager in tabelaBagrov)
            {
                if (bager.Leto >= mlajsi) koliko++; //prestejemo koliko bagrov je mlajsih od 12 let
            }
            Bager[] tabela = new Bager[koliko]; //ustvarimo tabelo, v katero bomo shranjevali bagre, mlajse od 12 let
            int i = 0;
            foreach (Bager bager in tabelaBagrov)
            {
                if (bager.Leto >= mlajsi)
                {
                    tabela[i] = bager; //vsak bager skopiramo v novo tabelo
                    i++;
                }
            }
            return tabela;

        }

        /// <summary>
        /// Preberite datoteko bagrov  in podatke zapišite na več datotek, 
        /// ločenih po letu izdelave bagrov.
        /// </summary>
        /// <param name="imeDatoteke"></param>
        public static void Prepisi(string imeDatoteke)
        {
            Bager[] tabela = PreberiZDatoteke (imeDatoteke); //celo datoteko preberem v tabelo
            foreach (Bager bager in tabela)
            {
                bager.DodajNaDatoteko(bager.Leto.ToString () + ".txt");
            }
        }



    }
}