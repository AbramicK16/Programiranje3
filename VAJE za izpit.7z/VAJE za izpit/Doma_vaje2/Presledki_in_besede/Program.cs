﻿using System;

namespace Presledki_in_besede
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Vnesi niz: ");
            string niz = Console.ReadLine();

            int koliko_presledkov = 0;
            string[] besede = niz.Split(" ", StringSplitOptions.RemoveEmptyEntries);

            foreach (char znak in niz)
            {
                if (Char.IsWhiteSpace(znak))
                {
                    koliko_presledkov++;
                }
            }

            Console.WriteLine("Število predledkov v nizu " + koliko_presledkov +".");
            Console.WriteLine("Število besed v nizu: " + besede.Length + ".");
            
            string brez_presledkov = "";
            string s_presledki = "";
            string brez_spredaj = "";
            int i = 1;
            int najkrajsa = 100;
            int najdaljsa = 0;
            string najkrajsa_b = "";
            string najdaljsa_b = "";
            Console.WriteLine("Niz izpisan po besedah: ");
            foreach(string beseda in besede)
            {
                brez_presledkov += beseda;
                s_presledki += " " + beseda;
                brez_spredaj += beseda + " ";
                Console.WriteLine(i + ". beseda: " + beseda);
                i++;
                if (beseda.Length > najdaljsa)
                {
                    najdaljsa = beseda.Length;
                    najdaljsa_b = beseda;
                }
                if (beseda.Length < najkrajsa)
                {
                    najkrajsa = beseda.Length;
                    najkrajsa_b = beseda;
                }

            }
            Console.WriteLine("Niz brez presledkov: " + brez_presledkov);
            Console.WriteLine("Niz brez zaporednih presledkov: " + s_presledki + " ");

            brez_spredaj = "Niz brez začetnih, končnih in zaporednih presledkov: " + brez_spredaj;
            brez_spredaj = brez_spredaj.Remove(brez_spredaj.Length - 1, 1) + "";
            Console.WriteLine(brez_spredaj);
            Console.WriteLine("Najdaljša beseda: " + najdaljsa_b);
            Console.WriteLine("Št. črk: " + najdaljsa);
            Console.WriteLine("Najkrajša beseda: " + najkrajsa_b);
            Console.WriteLine("Št. črk: " + najkrajsa);


        }
    }
}
