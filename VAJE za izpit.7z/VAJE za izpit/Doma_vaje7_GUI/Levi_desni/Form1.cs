﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Levi_desni
{
    public partial class Okno : Form
    {
        private string Besedilo = "pritisnjen";
        public Okno()
        {
            InitializeComponent();
        }

        private void button1_MouseUp(object sender, MouseEventArgs e)
        {
            this.label1.Text = "";
        }

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            this.label1.Text = "<- " + this.Besedilo;
        }

        private void button2_MouseUp(object sender, MouseEventArgs e)
        {
            this.label1.Text = "";
        }

        private void button2_MouseDown(object sender, MouseEventArgs e)
        {
            this.label1.Text = this.Besedilo + " ->";
        }
    }
}
