﻿using System;

namespace Dopolni_program2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program izpiše vrednost izraza (a+b)/c, za cela števila a,b,c");
            
            
            
        }

        public static int Preveri(int a, int b, int c)
        {
            try
            {
                Console.Write("Vnesi a: ");
                a = int.Parse(Console.ReadLine());
                Console.Write("Vnesi b: ");
                b = int.Parse(Console.ReadLine());
                Console.Write("Vnesi c: ");
                c = int.Parse(Console.ReadLine());
                Console.WriteLine("(a+b)/c = " + ((a + b) / c));
            }

            catch (FormatException)
            {
                Console.WriteLine("Uporabimo lahko samo cela števila");
                return Preveri(a, b, c);
            }

            catch (DivideByZeroException)
            {
                Console.WriteLine("Deliš z nič!");
                return Preveri(a, b, c);
            }

            catch (Exception e)
            {
                Console.WriteLine("Nekaj je šlo narobe:");
                Console.WriteLine(e.ToString());
                Console.WriteLine("Popravi program, da bo to izjemo obravnaval posebej.");
            }
            return c;
        }
    }
}
