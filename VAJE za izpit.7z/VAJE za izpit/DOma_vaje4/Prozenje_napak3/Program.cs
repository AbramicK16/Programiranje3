﻿using System;

namespace Prozenje_napak3
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());

            ničleKvadratneEnačbe(a, b, c);
        }

        public static void ničleKvadratneEnačbe(int a, int b, int c)
        {
            double x1, x2; //resitvi enacbe
            double determinanta = (b * b) - (4 * a * c);

            if (determinanta == 0)
            {
                x1 = -b / 2 * a;
                x2 = x1;

                Console.WriteLine("Prva ničla={0}" ,x1);
                Console.WriteLine("Druga ničla ničla={1}", x2);
                Console.WriteLine("Ničli sta enaki. ");
            }

            else if (determinanta > 0)
            {
                x1 = (-b + Math.Sqrt(determinanta)) / 2 * a;
                x2 = (-b - Math.Sqrt(determinanta)) / 2 * a;
                Console.WriteLine("Prva ničla={0}", x1);
                Console.WriteLine("Druga ničla ničla={0}", x2);
                Console.WriteLine("Ničli sta realni in različni. ");
            }

            else
            {
                x1 = (-b + Math.Sqrt(determinanta)) / 2 * a;
                x2 = (-b - Math.Sqrt(determinanta)) / 2 * a;
                Console.WriteLine("Prva ničla={0}", x1);
                Console.WriteLine("Druga ničla ničla={1}", x2);
                Console.WriteLine("Ničli sta imaginarni. ");
            }
        }
    }
}
