﻿using System;

namespace Lovljenje_napak2
{
    class Program
    {
        static void Main(string[] args)
        {
            string sporocilo = "Vnesi celo število: ";
            Console.Write(preberiInt(sporocilo));
        }

        public static int preberiInt(string sporocilo)
        {
            Console.Write(sporocilo);
            try
            {
                int stevilo = int.Parse(Console.ReadLine());
                return stevilo;
            }

            catch (FormatException)
            {
                Console.WriteLine("NAPAKA: nisi vnesel celega števila.");
                return preberiInt(sporocilo);
            }
           
        }
    }
}
