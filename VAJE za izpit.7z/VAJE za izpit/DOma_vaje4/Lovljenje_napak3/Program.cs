﻿using System;

namespace Lovljenje_napak3
{
    class Program
    {
        static void Main(string[] args)
        {
            string sporocilo = "Vnesi celo število med: ";
            Console.Write("Vnesi a: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("Vnesi b: ");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine(preberiIntMeje(sporocilo, a, b));
        }

        public static int preberiIntMeje(string sporocilo, int a, int b)
        {
            int stevilo;
            stevilo = preberiInt(sporocilo + a + " in " + b + ":");

            if (stevilo < a)
            {
                Console.WriteLine("NAPAKA: " + stevilo + " ni celo število med " + a + " in " + b + ".");
                return preberiIntMeje(sporocilo, a, b);
            }

            if (stevilo > b)
            {
                Console.Write("NAPAKA: " + stevilo + " ni celo število med " + a + " in " + b + ".");
                Console.WriteLine();
                return preberiIntMeje(sporocilo, a, b);
            }

            try
            {
                return stevilo;
            }

            catch (FormatException)
            {
                Console.WriteLine("NAPAKA: " + stevilo + " ni celo število med " + a + " in " + b + "." );
                Console.WriteLine();
            }

            return stevilo;

            


        }

        public static int preberiInt(string sporocilo)
        {
            Console.Write(sporocilo);
            try
            {
                int stevilo = int.Parse(Console.ReadLine());
                return stevilo;
            }

            catch (FormatException)
            {
                Console.WriteLine("NAPAKA: nisi vnesel celega števila.");
                return preberiInt(sporocilo);
            }

        }
    }
}
