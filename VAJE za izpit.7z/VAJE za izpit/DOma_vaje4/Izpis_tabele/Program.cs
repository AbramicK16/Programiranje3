﻿using System;

namespace Izpis_tabele
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tabela1 = new int[] { 12, 5, 6, 78, 3, 5, 6, 21, 434, 56, 42, 7 };
            string[] tabNizov = new string[] { "modra", "siva", "rumena", "rdeca", "zelena", "bela", "crna", "roza" };
            int n = 5;
            int m = 2;
            string vmes = " : ";
            string med = " - ";
            IzpisTabele(tabela1, n, vmes);
            IzpisTabele(tabNizov, m, med);
        }

        public static void IzpisTabele<T>(T[] tab, int n, string vmes)
        {
            //ta del izpiše vse polne vrstice
            int j = 0;
            for (int i = 0; i < tab.Length - n;)
            {
                for (int k = 0; k < n-1; k++)
                {
                    Console.Write(tab[i] + vmes);
                    i++;
                }
                Console.Write(tab[i] + "\n");
                i++;
                j = i;
            }

            //ta del izpiše še zadnjo vrsto
            while (j < tab.Length - 1)
            {
                Console.Write(tab[j] + vmes);
                j++;
            }
            Console.Write(tab[j] + "\n");

        }
    }
}
