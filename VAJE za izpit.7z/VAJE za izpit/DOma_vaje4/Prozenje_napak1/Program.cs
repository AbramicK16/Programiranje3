﻿using System;
using Lovljenje_napak2;

namespace Prozenje_napak1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = preberiInt("Vnesi celo število: ");
            racunanje(n);
                
        }

        public static void racunanje(int n)
        {
            for (int i = 0; i < n; i++)
            {
                Random rand = new Random();
                int a = rand.Next(0, 11);
                int b = rand.Next(0, 11);
                int c = rand.Next(0, 3);
                int vneseno_st; //vnese uporabnik
                int koncen_rezultat = 0;
                string[] operacije = new string[] { "+", "-", "*" };

                if (c == 0)
                {
                    koncen_rezultat = a + b;
                }

                if (c == 1)
                {
                    koncen_rezultat = a - b;
                }

                if (c == 2)
                {
                    koncen_rezultat = a * b;
                }

                string racun = a + operacije[c] + b + " = ";
                while (true) //zanko uporabljamo, dokler uporabnik ne vnese pravega rezultata
                {
                    vneseno_st = preberiInt(racun);
                    if (vneseno_st == koncen_rezultat) { break; }
                }
            }
        }


        public static int preberiInt(string sporocilo)
        {
            Console.Write(sporocilo);
            try
            {
                int stevilo = int.Parse(Console.ReadLine());
                return stevilo;
            }

            catch (FormatException)
            {
                Console.WriteLine("NAPAKA: nisi vnesel celega števila.");
                return preberiInt(sporocilo);
            }

        }
    }
}
