﻿using System;

namespace Min_Max
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tab1 = new int[] { 5, 13, -3, 8, 9, 73, 54, -6, 66 };
            string[] tabNizov = new string[] { "rdeca", "modra", "abeceda", "luna" };
            Console.WriteLine("Min: " + MinMax(tab1)[0] + " " + "Max: " + MinMax(tab1)[1]);
            Console.WriteLine("Min: " + MinMax(tabNizov)[0] + " " + "Max: " + MinMax(tabNizov)[1]);
        }

        //za genericne tipe
        public static T[] MinMax<T>(T[] tabela) where T : IComparable<T>
        {
            T min = tabela[0];
            T maks = tabela[0];
            for (int i = 0; i < tabela.Length; i++)
            {
                T element = tabela[i];
                if (element.CompareTo(min) < 0)
                {
                    min = element;
                }
                if (element.CompareTo(maks) > 0)
                {
                    maks = element;
                }
            }
            T[] tabDvehElementov = new T[] { min, maks };
            return tabDvehElementov;
        }

        public static string[] MinMag(string[] tabela)
        {
            string najmanjsi = "";
            string najvecji = "";
            foreach (string niz in tabela)
            {
                if (najmanjsi == "")
                {
                    najmanjsi = niz;
                }

                if (najmanjsi.Length > niz.Length)
                {
                    najmanjsi = niz;
                }

                if (najvecji.Length < niz.Length)
                {
                    najvecji = niz;
                }
                
            }
            string[] tabNizov = new string[] { najmanjsi, najvecji };
            return tabNizov;
        }


    }
}
