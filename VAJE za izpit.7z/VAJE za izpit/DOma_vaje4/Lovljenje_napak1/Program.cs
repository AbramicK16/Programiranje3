﻿using System;

namespace Lovljenje_napak1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tabela = tabeliraj(10);
            IzpisTabele(tabela);
        }

        public static int[] tabeliraj(int velikost)
        {
            int[] mojaTabela = new int[velikost];
            for (int i = 0; i < velikost; i++)
            {
                try
                {
                    mojaTabela[i] = F(i);
                }
                catch
                {
                    mojaTabela[i] = 0;
                }
            }
            return mojaTabela;
        }

        public static void IzpisTabele(int[] tab)
        {
            foreach(int el in tab)
            {
                Console.Write(el + " ");
            }
            Console.WriteLine();
        }

        public static int F(int i)
        {
            return 100 / (i % 3);
        }
    }
}
