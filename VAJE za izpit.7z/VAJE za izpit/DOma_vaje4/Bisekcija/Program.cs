﻿using System;

namespace Bisekcija
{
    class Program
    {
        static void Main(string[] args)
        {
            int podatek = int.Parse(Console.ReadLine());

            int[] tab1 = new int[] { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 };
            int[] tab2 = new int[] { 11, 21, 34, 44, 51, 67, 68, 100, 105 };
            int[] tab3 = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            Bisekcija(tab1, podatek);
            Bisekcija(tab2, podatek);
            Bisekcija(tab3, podatek);
        }

        public static int Bisekcija<T>(T[] tabela, T podatek) where T : IComparable<T>
        {
            int zacetek = 0;
            int konec = tabela.Length - 1;
            int polovica = konec / 2;

            while (konec - zacetek > 0)
            {
                if (podatek.CompareTo(tabela[polovica]) == 0) //ce je podatek na sredini
                {
                    Console.WriteLine("Podatek je vsebovan v tabeli."); //podatek je elemnt tabele
                    return 0;
                }

                if (podatek.CompareTo(tabela[polovica]) < 1) //če je podatek v prvi polovici
                {
                    konec = polovica - 1;
                }

                else //če je podatek v drugi polovici
                {
                    zacetek = polovica + 1;
                }
                polovica = (zacetek + konec) / 2; //določimo novo polovico

            }
            Console.WriteLine("Podatka ni v tabeli."); //podatka zagotovo ni vtabeli
            return -1; //elementa ni v tabeli
        }
    }
}
