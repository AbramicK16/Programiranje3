﻿using System;

namespace Razred_Kosarica
{
    class Program
    {
        static void Main(string[] args)
        {
            Kosarica<int> cela = new Kosarica<int>(5);
            Console.WriteLine(cela);
            Kosarica<string> niz = new Kosarica<string>("Programiranje");
            Console.WriteLine(niz);
            Kosarica<double> realna = new Kosarica<double>(3.14);
            Console.WriteLine(realna);

            int[] tab = new int[] { 2, 4, 6, 8 };
            Kosarica<int[]> kosarica_tabel = new Kosarica<int[]>(tab);
            Console.WriteLine(kosarica_tabel);
        }
    }
}
