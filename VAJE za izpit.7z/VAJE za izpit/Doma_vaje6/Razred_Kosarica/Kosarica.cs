﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Razred_Kosarica
{
    public class Kosarica<T>
    {
        private T objekt;

        public T Objekt
        {
            get { return this.objekt; }
            set { this.objekt = value; }
        }

        public Kosarica(T obj)
        {
            this.objekt = obj;
        }

        public override string ToString()
        {
            return this.objekt.ToString();
        }
    }
}
