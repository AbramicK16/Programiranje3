﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Razred_kolo
{
    public class Kolo
    {
        private string[] sezBarv = new string[] { "modra", "rdeca", "zelena", "rumena", "roza", "crna", "bela", "siva", "oranžna" }
        private string[] sezTip = new string[] { "gorsko", "cestno", "treking" };
        private int stPrestav;
        private string barveKolesa;
        private string tipKolesa;
        private int leto;
        private int kolikoOseb;

        public int Prestave
        {
            get { return this.stPrestav; }
            set
            {
                if (value < 0) throw new Exception("Stevilo prestav ne more biti negativno! ");
                this.stPrestav = value;
            }
        }

        public string Barva
        {
            get { return this.barveKolesa; }
            set 
            {
                
                if (sezBarv.Contains(value)) { this.barveKolesa = value; }
                this.barveKolesa = value; 
            }
        }

        public string Tip
        {
            get { return this.tipKolesa; }
            set
            {
                if (sezTip.Contains(value)) { this.tipKolesa = value; }
                this.tipKolesa = value;
            }
        }

        public int Leto
        {
            get { return this.leto; }
            set { this.leto = value; }
        }

        public int Koliko
        {
            get { return this.kolikoOseb; }
            set 
            {
                if (value < 0) throw new Exception("Ni prou");
                this.kolikoOseb = value;
            }
        }

        public Kolo()
        {
            this.Prestave = 3;
            this.Barva = "modra";
            this.Tip = "gorsko";
            this.Leto = DateTime.Now.Year;
            this.Koliko = 5;
        }

        public Kolo(int pre, string bar, string t,int l, int kl)
        {
            this.Prestave = pre;
            this.Barva = bar;
            this.Tip = t;
            this.Leto = l;
            this.Koliko = kl;

        }

        /*public Kolo(string opis)
        {
            string[] tabela = opis.Split(", ");

            int prestave = int.Parse(tabela[0]);
            if (prestave < 0) throw new Exception("Stevilo prestav ne more biti negativno! ");
            this.stPrestav = prestave;

            this.Barva = tabela[1];

            string tip = tabela[]
        }*/

        public void Prebarvaj(Kolo[] tabela)
        {
           foreach(Kolo kolo in tabela)
            {
                if (kolo.Barva == "rumena")
                {
                    kolo.Barva = "rdeča";
                }
            }
        }

        public int KolikoNaCesti(Kolo[] tabela)
        {
            int stevec = 0;
            foreach (Kolo kolo in tabela)
            {
                if (kolo.Tip == "cestno")
                {
                    stevec += kolo.Koliko;
                }
            }
            return stevec;
        }

        public static Kolo[] Odstrani(Kolo[] tabela)
        {
            int koliko = 0;
            int mlajsa = DateTime.Now.Year - 12;
            foreach (Kolo kolo in tabela)
            {
                if (kolo.Leto >= mlajsa)
                {
                    koliko++;
                }
            }
            Kolo[] sez = new Kolo[koliko];
            int i = 0;
            foreach (Kolo kolo in sez)
            {
                if (kolo.Leto >= mlajsa)
                {
                    sez[i] = kolo;
                    i++;
                }
            }
            return sez;
        }


    }
}
