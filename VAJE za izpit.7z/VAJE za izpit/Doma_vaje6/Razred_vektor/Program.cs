﻿using System;

namespace Razred_vektor
{
    class Program
    {
        static void Main(string[] args)
        { 
            Vektor v1 = new Vektor(3, 4);
            Vektor v2 = new Vektor(2, -3);
            Vektor v3 = new Vektor();
            Vektor v4 = new Vektor(3, 4);

            Console.WriteLine("({0},{1})", v3.X,v3.Y);

            Vektor v5 = v1 + v2;
            Console.WriteLine("({0},{1})", v5.X, v5.Y);
        }
    }
}
