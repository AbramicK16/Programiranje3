﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Razred_vektor
{
    /// <summary>
    /// Razred Vektor predstavlja dvodimenzionalne vektorje s celoštevilskimi koordinatami.
    /// KOnstruktor brez parametrov predstavlja vektor (1,1), s parametroma pa predstavlja vektor (x,y)
    /// </summary>
    public class Vektor 
    {
        private int x;
        private int y;

        public int X
        {
            get { return this.x; }
            set { this.x = value; }
        }

        public int Y
        {
            get { return this.y; }
            set { this.y = value; }
        }

        public Vektor()
        {
            this.X = 1;
            this.Y = 1;
        }

        public Vektor(int x, int y)
        {
            this.X = x;
            this.Y = y;
        }

        private double Length
        {
            get { return Math.Sqrt(Math.Pow(Convert.ToDouble(this.X), 2) + Math.Pow(Convert.ToDouble(this.Y), 2)); }
        }

        public override string ToString()
        {
            string niz = "(" + this.X + ", " + this.Y + ")";
            return niz;
        }

        //+, -, *(mnozenje s celim st), *(skalarni produkt dveh vektorjev)
        public static Vektor operator +(Vektor v1, Vektor v2)
        {
            return new Vektor(v1.X + v2.X, v1.Y + v2.Y);
        }

        public static Vektor operator -(Vektor v1, Vektor v2)
        {
            return new Vektor(v1.X - v2.X, v1.Y - v2.Y);
        }

        public static Vektor operator *(Vektor v1, int s)
        {
            return new Vektor(v1.X * s, v1.Y * s);
        }

        public static Vektor operator *(int s, Vektor v1)
        {
            return new Vektor(s * v1.X, s * v1.Y);
        }

        public static int operator *(Vektor v1, Vektor v2)
        {
            return v1.X * v2.X + v1.Y + v2.Y;
        }

        // ++, --, -(Vektor)
        public static Vektor operator ++(Vektor v1)
        {
            return v1 + new Vektor(); //vektorju prištejemo vektor (1,1)
        }

        public static Vektor operator --(Vektor v1)
        {
            return v1 - new Vektor(); //vektorju odštejemo vektor (1,1)
        }

        public static Vektor operator -(Vektor v1)
        {
            return v1 - (v1 * 2);
        }

        //Equals, ==, !=
        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public static bool operator ==(Vektor v1, Vektor v2)
        {
            return v1.Equals(v2);
        }

        public static bool operator !=(Vektor v1, Vektor v2)
        {
            return !v1.Equals(v2);
        }

        //<, >, >=, <=
        public static bool operator <(Vektor v1, Vektor v2)
        {
            return (v1.Length < v2.Length);
        }

        public static bool operator >(Vektor v1, Vektor v2)
        {
            return (v1.Length > v2.Length);
        }

        public static bool operator <=(Vektor v1, Vektor v2)
        {
            return (v1.Length <= v2.Length);
        }

        public static bool operator >=(Vektor v1, Vektor v2)
        {
            return (v1.Length >= v2.Length);
        }

        //true, false
        public static bool operator true(Vektor v1)
        {
            return (v1.X != 0 || v1.Y != 0);
        }

        public static bool operator false(Vektor v1)
        {
            return (v1.X == 0 && v1.Y == 0);
        }

        //&,|,^
        public static bool operator &(Vektor v1, Vektor v2)
        {
            if (v1)
            {
                if (v2)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator |(Vektor v1, Vektor v2)
        {
            if (v1)
            {
                return true;
            }
            if (v2)
            {
                return true;
            }
            return false;
        }

        public static bool operator ^(Vektor v1, Vektor v2)
        {
            if (v1 & v2)
            {
                return false;
            }
            if (!(v1 | v2))
            {
                return false;
            }
            return true;
        }


    }

}
