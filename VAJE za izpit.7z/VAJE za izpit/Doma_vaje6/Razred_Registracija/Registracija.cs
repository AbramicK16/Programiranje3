﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace Razred_Registracija
{
    public class Registracija
    {
        private string registracija;
        private string obmocje;
        private string[] tabelaObmocij = new string[] { "LJ", "KR", "KK", "MB", "MS", "KP", "GO", "CE", "SG", "NM", "PO" };

        public string Registrska_st
        {
            get { return this.registracija; }
            set 
            { 
                if(value.Length == 5) { this.registracija = value; }
                throw new Exception("Neveljavna registracija");
            }
        }

        public string Obmocje
        {
            get { return this.obmocje; }
            set
            {
                if (!obmocje.Contains(value)) throw new Exception("To obmocje je neveljavno!");
                else { this.obmocje = value; }
            }
        }

        public string[] Tabela
        {
            get { return this.tabelaObmocij; }
        }

        public Registracija(string registr, string obm)
        {
            this.registracija = registr;
            this.obmocje = obm;
        }

        public override string ToString()
        {
            return this.registracija + " " + this.obmocje;
        }

        public void DodamoNovo(string obm)
        {
            if (!this.tabelaObmocij.Contains(obm))
            {
                string[] tabela_obmocij = new string[tabelaObmocij.Length + 1];
                for (int i = 0; i < this.tabelaObmocij.Length; i++)
                {
                    tabela_obmocij[i] = this.tabelaObmocij[i];
                }
                tabela_obmocij[this.tabelaObmocij.Length] = obm;
                this.tabelaObmocij = tabela_obmocij;
            }
        }

        /// <summary>
        /// Iz tabele obmocij odstranimo obmocje obm
        /// Ce tega obmocja ni v tabeli, vrnemo napako
        /// </summary>
        /// <param name="obm"></param>
        public void Odstrani(string obm)
        {
            if (!this.tabelaObmocij.Contains(obm))
            {
                throw new Exception("Tega območja ni v tabeli! ");
            }
            else
            {
                string[] novaTabela = new string[this.tabelaObmocij.Length - 1];
                int i = 0;
                foreach(string niz in this.tabelaObmocij)
                {
                    if (niz != obm)
                    {
                        novaTabela[i] = this.tabelaObmocij[i];
                        i++;
                    }
                }
                this.tabelaObmocij = novaTabela;
            }
        }


    }

    
}
