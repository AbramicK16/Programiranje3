﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Razred_Polonica
{
    public class Polonica
    {
        private int starost; //v tednih
        private int stPik;

        public int Starost
        {
            get { return this.starost; }
            set
            {
                if (value > 208) throw new Exception("Pikapoke ne dosezejo 4 let");
                this.starost = value;
            }
        }

        public int Pike
        {
            get { return this.stPik; }
            set
            {
                if (value > 7) throw new Exception("Nimajo več kot 7 pik! ");
                this.stPik = value;
            }
        }

        public Polonica(int starost, int stPik)
        {
            this.Starost = starost;
            this.Pike = stPik;
        }

        public override string ToString()
        {
            return "Jaz sem Pikapoka, stara " + this.Starost.ToString() + " tednov in imam " + this.Pike.ToString() + " pik.";
        }

        /*public Polonica[] operator *(int x, Polonica p)
        {
            return new Polonica[] { x * p };

        }*/

        public int SteviloPik(Polonica[] tabela)
        {
            int stevec = 0;
            foreach(Polonica Polo in tabela)
            {
                if (Polo.Starost > 52)
                {
                    stevec += Polo.Pike;
                }
            }
            return stevec;
        }
    }
}
