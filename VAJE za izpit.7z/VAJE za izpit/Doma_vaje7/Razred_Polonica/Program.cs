﻿using System;

namespace Razred_Polonica
{
    class Program
    {
        static void Main(string[] args)
        {
            Polonica p1 = new Polonica(8, 4);
            Polonica p2 = new Polonica(54, 6);
            Polonica p3 = new Polonica(156, 2);

            Console.WriteLine(p2.ToString());
        }
    }
}
