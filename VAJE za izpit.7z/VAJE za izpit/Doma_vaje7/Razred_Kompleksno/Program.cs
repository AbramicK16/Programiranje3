﻿using System;

namespace Razred_Kompleksno
{
    class Program
    {
        static void Main(string[] args)
        {
            Kompleksno_stevilo k1 = new Kompleksno_stevilo(2, -1);
            Kompleksno_stevilo k2 = new Kompleksno_stevilo(3, 4);
            Kompleksno_stevilo k3 = new Kompleksno_stevilo(0, 1);

            Console.WriteLine("Vsota: {0}", k1 + k2);
            Console.WriteLine(k2.ToString());
            Console.WriteLine(k2.R);
            Console.WriteLine(k1.ToString());
        }
    }
}
