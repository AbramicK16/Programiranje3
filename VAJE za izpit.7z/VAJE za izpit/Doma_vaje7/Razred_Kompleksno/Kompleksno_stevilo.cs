﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Razred_Kompleksno
{
    public class Kompleksno_stevilo
    {
        private double re;
        private double im;

        public double Re
        {
            get { return this.re; }
            set { this.re = value; }
        }

        public double Im
        {
            get { return this.im; }
            set { this.im = value; }
        }

        public Kompleksno_stevilo(double real, double im)
        {
            this.Re = real;
            this.im = im;
        }

        public double R
        {
            get { return Math.Sqrt(Math.Pow(this.Re, 2) + Math.Pow(this.Im, 2)); }
        }

        public double Arg
        {
            get { return Math.Atan2(this.Im, this.Re); }
        }

        public override string ToString()
        {
            string niz = this.Re.ToString() + " + " + this.Im.ToString() +"i";

            if (this.Im < 0) niz = this.Re.ToString() + " - " + this.Im.ToString() + "i";
            if (this.Re == 0) niz = this.Im.ToString();
            if (this.Im == 0) niz = this.Re.ToString();

            if (this.Im == 1 && this.Re != 0) niz = this.Re.ToString() + " + i";
            if (this.Im == 1 && this.Re == 0) niz = "i";
            if (this.Im == -1 && this.Re == 0) niz = "- i";
            if (this.Im == -1 && this.Re != 0) niz = this.Re.ToString() + " - i";
            return niz;
        }

        public static Kompleksno_stevilo operator +(Kompleksno_stevilo k1, Kompleksno_stevilo k2)
        {
            return new Kompleksno_stevilo(k1.Re + k2.Re, k1.Im + k2.Im);
        }

    }
}
