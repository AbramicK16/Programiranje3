﻿using System;

namespace Razred_Vektor
{
    class Program
    {
        static void Main(string[] args)
        {
            Vektor v1 = new Vektor(2, 5, 3);
            Vektor v2 = new Vektor(-3, 6, 4);

            Vektor v3 = v1 + v2;
            Console.WriteLine("{0},{1},{2}", v3.X, v3.Y, v3.Z);
            Console.WriteLine(v3.ToString());
            Console.WriteLine(v3.Dolzina);
        }
    }
}
