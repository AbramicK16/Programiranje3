﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Razred_Vektor
{
    public class Vektor
    {
        private int x;
        private int y;
        private int z;

        public int X
        {
            get { return this.x; }
            set { this.x = value; }
        }

        public int Y
        {
            get { return this.y; }
            set { this.y = value; }
        }

        public int Z
        {
            get { return this.z; }
            set { this.z = value; }
        }

        public Vektor(int prva, int druga, int tretja)
        {
            this.X = prva;
            this.Y = druga;
            this.Z = tretja;
        }

        public double Dolzina
        {
            get { return Math.Sqrt((Math.Pow(Convert.ToDouble(this.x),2)) + Math.Pow(Convert.ToDouble(this.Y),2) + Math.Pow(Convert.ToDouble(this.Z),2)); }
        }

        public override string ToString()
        {
            return "(" + this.X + ", " + this.Y + ", " + this.Z + ")";
        }

        public static Vektor operator +(Vektor v1, Vektor v2)
        {
            return new Vektor(v1.X + v2.X, v1.Y + v2.Y, v1.Z + v2.Z);
        }

    }
}
