﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Naloga_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public double pravilni = 0;
        public int odg = -1;
        public Random rnd = new Random();
        public string[] bar = new string[] { "RDEČA", "MODRA", "ZELENA" };

        private void ponastavi()
        {
            timer1.Stop();
            timer1.Start();
            odg++;
            label1.Text = "Pravilni: " + pravilni + "       vsi: " + odg;
            label1.Text = bar[rnd.Next(0, 3)];
            int naklj = rnd.Next(0, 3);
            if (naklj == 0) { label1.ForeColor = Color.Red; }
            else if (naklj == 1) { label1.ForeColor = Color.Blue; }
            else { label1.ForeColor = Color.Green; }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ponastavi();
            timer1.Enabled = true;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (!(label1.Text == "MODRA" && label1.ForeColor == Color.Blue)
                || (label1.Text == "RDEČA" && label1.ForeColor == Color.Red)
                || (label1.Text == "ZELENA" && label1.ForeColor == Color.Green))
            {
                pravilni++;
            }

            ponastavi();
        }



    private void button2_Click(object sender, EventArgs e)
        {
            if (((label1.Text == "MODRA" && label1.ForeColor == Color.Blue)
              || (label1.Text == "RDEČA" && label1.ForeColor == Color.Red)
              || (label1.Text == "ZELENA" && label1.ForeColor == Color.Green)))
            {
                pravilni++;
            }

            ponastavi();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ponastavi();

        }


    }
}
