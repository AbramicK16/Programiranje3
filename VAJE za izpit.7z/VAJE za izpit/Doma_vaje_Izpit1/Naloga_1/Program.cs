﻿using System;

namespace Naloga_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tab = new int[] { 3, 7, 9, 5, 11 };
            IzpisiTab(tab);
            int[] novaTab = SpremeniTabelo(tab);
            IzpisiTab(novaTab);
            string[] tabImen = { "Ana", "Mojca", "Eva", "Anže", "Jan" };
            IzpisiTab(tabImen);
            string[] novaIme = Spremeni(tabImen);
            IzpisiTab(novaIme);
            int[] tabSt = { 11, 5, -6, 3, 0 };
            IzpisiTab(tabSt);
            int[] novaSt = Spremeni(tabSt);
            IzpisiTab(novaSt);
        }

        public static int[] SpremeniTabelo(int[] tab)
        {
            int dolzina = 0; //dolzina nove tabele
            for (int i = 1; i <= tab.Length; i++)
            {
                dolzina += i;
            }
            int k = 0;
            int[] novaTabela = new int[dolzina];
            for (int i = 1; i <= tab.Length; i++)
            {
                for (int j = 0; j < i; j++)
                {
                    novaTabela[i + j - 1 + k] = tab[i - 1];
                }
                k = k + i - 1;
            }
            return novaTabela;
        }

        public static T[] Spremeni<T>(T[] tab)
        {
            int dolzina = 0; //dolzina nove tabele
            for (int i = 1; i <= tab.Length; i++)
            {
                dolzina += i;
            }
            int k = 0;
            T[] novaTabela = new T[dolzina];
            for (int i = 1; i <= tab.Length; i++)
            {
                for (int j = 0; j < i; j++)
                {
                    novaTabela[i + j - 1 + k] = tab[i - 1];
                }
                k = k + i - 1;
            }
            return novaTabela;
        }

        public static void IzpisiTab<T>(T[] tab)
        {
            foreach (T el in tab)
            {
                Console.Write(el + " ");
            }
            Console.WriteLine();
        }
    }
}
