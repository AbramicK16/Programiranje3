﻿using System;

namespace Naloga_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Vnesi zgornjo mejo: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("Vnesi spodnjo mejo: ");
            int b = int.Parse(Console.ReadLine());
            Console.Write("Vnesi poljubno število: ");
            int k = int.Parse(Console.ReadLine());
            Console.Write(PoisciCela(a, b, k));

        }

        public static string PoisciCela(int a, int b, int k)
        {
            string rez = "Cela števila z intervala [" + a + ", " + b + "], v katerih vsaka neničelna številka deli število " + k + " so: ";

            int kolikoStevil = 0; //koliko stevil deli k
            for (int i = a; i <= b; i++)
            {
                string stevilo = i.ToString();
                int kolikoStevk = 0;
                foreach (char znak in stevilo)
                {
                    int stevka = int.Parse(znak.ToString());
                    if (stevka == 0)
                    {
                        kolikoStevk++;
                        continue;
                    }

                    if (k % stevka == 0)
                    {
                        kolikoStevk++;
                    }
                }
                if (stevilo.Length == kolikoStevk)
                {
                    rez = rez + stevilo + ", ";
                    kolikoStevil++;
                }
            }
            if (kolikoStevil > 0)
            {
                rez = rez.Remove(rez.Length - 2, 2) + ".";
                return rez;
            }
            else //ce ni nobenega števila, ki bi delilo k
            {
                return "V intervalu [" + a + ", " + b + "] ni celih števil, v katerih vsaka neničelna števka deli " + k + ".";
            }
        }
    }
}
