﻿using System;
using System.IO;
using System.Reflection.Metadata;

namespace Naloga_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }

        public static void Datoteke(string vhod, string izhod)
        {
            if (!File.Exists(vhod)) throw new Exception("Datoteka ne obstaja!");
            StreamWriter pisanje = File.CreateText(izhod);
            StreamReader branje = File.OpenText(vhod);

            string vrstica = branje.ReadLine();
            string[] tab = vrstica.Split(", ");
            string Ime = tab[0];
            string Starost = tab[1];
            string Teza = tab[2];

            while (vrstica != null)
            {
                vrstica = branje.ReadLine();
                string[] podatki = vrstica.Split(", ");
                var parIme = (Ime, podatki[0]);
                var parStarost = (Starost, podatki[1]);
                var parTeza = (Teza, podatki[2]);
                (string, string)[] tabela = { parIme, parStarost, parTeza };
                pisanje.WriteLine(tabela);
            }

            pisanje.Close();
            branje.Close();
        }
    }
}
