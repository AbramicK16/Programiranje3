﻿using System;

namespace Naloga_1
{
    class Program
    {

        static void Main(string[] args)
        {
            int[] tab1 = new int[] { 5, 4, 3, 2, 1 };
            string[] niz1 = new string[] { "Danes", "je", "lep", "dan" };

            try
            {
                VrniNtiElement(tab1, -5);
                VrniNtiElement(niz1, -5);
            }
            catch (Exception e) 
            {
                Console.WriteLine(e.Message);
            }
        }

        public static void VrniNtiElement<T>(T[] tab, int N)
        {
            if (N == 0) throw new Exception("Tega elementa ni v tabeli");
            if (Math.Abs(N) > tab.Length) throw new Exception("Tega elementa ni v tabeli");
            if (N < 0) { Console.WriteLine(tab[tab.Length + N]); }
            else { Console.WriteLine(tab[N-1]); }
        }
    }
}
