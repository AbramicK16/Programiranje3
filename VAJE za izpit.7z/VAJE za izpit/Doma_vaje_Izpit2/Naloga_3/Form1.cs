﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Naloga_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int min = 0;
        int sek = 0;
        int milisek = 0;

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            milisek += 1;
            label1.Text = min + " : " + sek + " : " + milisek;
            if (milisek == 100)
            {
                milisek = 0;
                sek += 1;
                label1.Text = min + " : " + sek + " : " + milisek;
                if (sek == 60)
                {
                    sek = 0;
                    min += 1;
                    label1.Text = min + " : " + sek + " : " + milisek;
                    if (min == 60)
                    {
                        timer1.Stop();
                        min = 0;
                        sek = 0;
                        milisek = 0;
                        label1.Text = min + " : " + sek + " : " + milisek;

                    }
                }

            }
        }

        

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }
    }
}
