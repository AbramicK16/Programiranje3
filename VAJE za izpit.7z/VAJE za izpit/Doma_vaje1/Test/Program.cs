﻿using System;

namespace Test
{
    class Program
    {
        public static void Main()
        {
            int a = 18;
            string niz = a + ""; // število spremeniš v niz
            int stevec = 0;
            for (int i = 0; i < niz.Length; i++)
            {
                stevec = stevec + int.Parse(niz[i] + ""); // + "" je zato da char spremeniš v string, ker int.Parse(char) ne dela
            }
            Console.WriteLine(stevec);


        }
    }
}
