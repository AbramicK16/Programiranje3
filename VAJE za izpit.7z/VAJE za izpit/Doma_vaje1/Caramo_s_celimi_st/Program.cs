﻿using System;

namespace Caramo_s_celimi_st
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, decimalke;
            int k = 0;
            int ostanek, celi_del;
            string rezultat;
            Console.Write("Vnesi stevec: " );
            a = int.Parse(Console.ReadLine());
            Console.Write("Vnesi imenovalec: ");
            b = int.Parse(Console.ReadLine());
            Console.Write("Koliko decimalk: ");
            decimalke = int.Parse(Console.ReadLine());
            ostanek = a % b;
            rezultat = a / b + ".";

            while (k <= 10)
            {
                ostanek = ostanek * 10;
                celi_del = ostanek / b;
                rezultat = rezultat + celi_del.ToString();
                k++;
                ostanek = ostanek % b;

            }
            Console.WriteLine(a + "/" + b + "=" + rezultat);

        }
    }
}

