﻿using System;

namespace Pozri_nicle
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Vnesi število: ");
            int stevilo = int.Parse(Console.ReadLine());

            string st = stevilo.ToString();
            string st_brez_nic = st.Replace("0", "");
            Console.WriteLine(st_brez_nic);

            
        }
    }
}
