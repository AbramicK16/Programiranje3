﻿using System;
using System.Globalization;
using System.Text.Json;

namespace Deljiva_stevila
{
    class Program
    {
        /*Izpiši tista števila med a in b (podatka, ki ju prebereš), 
        ki so deljiva z vsoto svojih števk. Npr. 12 je že deljivo z 
        vsoto števk (3). Prav tako 1101. Če sta torej podatka 8 in 14, 
        naj program izpiše:
        Med 8 in 14 so z vsoto svojih števk deljiva naslednja števila: 8, 9, 10, 12.*/

        static void Main(string[] args)
        {
            Console.Write("Zacetek intervala: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("Konec intervala: ");
            int b = int.Parse(Console.ReadLine());

            for (int i = a; i <= b; i++)
            {

                string niz = "Med " + a + " in " + b + " so z vsoto svojih števk deljiva naslednja števila: ";

                string st = i.ToString();
                string nizA = a.ToString();
                string nizB = b.ToString();
                int koliko = 0; //stevec
                for (int j = 0; j < st.Length; j++)
                {
                    koliko = koliko + int.Parse(st[j] + ""); // + "" je zato da char spremeniš v string, ker int.Parse(char) ne dela
                }

                if (i % koliko == 0)
                {
                    niz = niz + i + ", ";
                }

                //da se znebim vejce
                else
                {
                    niz = niz.Remove(niz.Length - 2, 2) + ".";
                }

                Console.WriteLine(niz);
            }

        }
    }
}
