﻿using System;

namespace Obrni_stevilo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Vnesi stevilo: ");
            string stevilo = Console.ReadLine();
            char[] charArray = stevilo.ToCharArray();
            Array.Reverse(charArray);
            Console.WriteLine(charArray);

        }
    }
}
