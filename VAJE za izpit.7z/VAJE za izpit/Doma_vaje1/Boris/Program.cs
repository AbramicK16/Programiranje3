﻿using System;

namespace Boris
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Masa v regiji A: ");
            double masaA = double.Parse(Console.ReadLine());
            Console.Write("Masa v regiji B: ");
            double masaB = double.Parse(Console.ReadLine());
            int korak = 0;
            double staraA;
            while(masaA + masaB > 0.001)
            {
                Console.WriteLine(korak + ", " + masaA + ", " + masaB);
                masaA = masaA * 0.12 + masaB * 0.22;
                staraA = masaA;
                masaB = masaB * 0.12 + staraA * 0.22;
                korak++;
               
            }
        }
    }
}
