﻿using System;

namespace Stevke_so_delitelji
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Vnesi spodnjo mejo intervala: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("Vnesi zgornjo mejo intervala: ");
            int b = int.Parse(Console.ReadLine());
            Console.Write("Vnesi celo število: ");
            int k = int.Parse(Console.ReadLine());

            Console.WriteLine(PoisciCela(a,b,k));


        }

        public static string PoisciCela(int a, int b, int k)
        {
            int kolikoStevil = 0; //koliko stevil deliko k
            string rez = "Cela števila iz intervala [" + a + ", " + b + "], v katerih vsaka neničelna števka deli " + k + " so: ";
            for (int i = a; i <= b; i++)
            {
                string stevilo = i.ToString(); //stevilo spremenim v niz

                //zdej pogledamo še števke v posameznem številu
                int kolikoStevk = 0; //koliko stevk v stevilu

                foreach (char znak in stevilo)
                {
                    int j = int.Parse(znak.ToString()); //znak spremenim v niz in nato se v celo št
                    if (j == 0) //ce je stevka 0, gremo dalje
                    {
                        kolikoStevk++;
                        continue;
                    }

                    if (k % j == 0)
                    {
                        kolikoStevk++;
                    }
                }
                if (stevilo.Length == kolikoStevk)
                {
                    rez = rez + stevilo + ", ";
                    kolikoStevil++;
                }
                
            }
            if (kolikoStevil > 0)
            {
                rez = rez.Remove(rez.Length - 2, 2) + ".";
                return rez;
            }
            else //ce ni nobenega števila, ki bi delilo k
            {
                return "V intervalu [" + a + ", " + b + "] ni celih števil, v katerih vsaka neničelna števka deli " + k + ".";
            }
        }

    }
}
