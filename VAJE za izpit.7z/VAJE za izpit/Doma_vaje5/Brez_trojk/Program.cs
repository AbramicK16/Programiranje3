﻿using System;

namespace Brez_trojk
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int[] tab = new int[] { 1, 2, 3, 5, 8, 13, 21, 31, 33, 55, 73, 113, 138, 221, 293 };
            IzpisTabele(tab);
            Krajšaj(ref tab);
            IzpisTabele(tab);
        }

        public static void Krajšaj(ref int[] tabela)
        {
            string nizBrezTrojk = ""; // v niz dodajamo števila brez trojk, ločena s presledkom (nizBrezTrojk = "1 2 5 8 1 21 1 ...)
            for (int i = 0; i < tabela.Length; i++)
            {
                string niz = tabela[i].ToString();
                niz = niz.Replace("3", "");
                if (niz != "")
                {
                    nizBrezTrojk += niz + " ";
                }
            }
            string[] tabNizov = nizBrezTrojk.Split(" "); // z niza naredimo tabelo ki vsebuje nize (tabNizov = ["1", "2", "5", "8", "1", "21", "1", ...])
            int[] tabSt = new int[tabNizov.Length - 1];
            // elemente prepišemo v novo tabelo in jih sproti pretvarjamo v nize
            for (int i = 0; i < tabNizov.Length - 1; i++) // -1 ker split zaradi presledka na koncu v tabNizov doda še ""
            {
                tabSt[i] = int.Parse(tabNizov[i]);
            }
            tabela = tabSt;

        }
        public static void IzpisTabele<T>(T[] tab)
        {
            string izpis = "";
            foreach (T el in tab)
            {
                izpis += el + ", ";
            }
            izpis = izpis.Remove(izpis.Length - 2);
            System.Console.WriteLine(izpis);
        }
    }
}
