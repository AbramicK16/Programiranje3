﻿using System;

namespace VrniNtiElement
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tab1 = new int[] { 1, 2, 5, 8, 13, 24 };
            string[] niz1 = new string[] { "bla", "blo", "bli" };
            string[] niz2 = new string[] { "a", "e", "i", "o", "u" };

            try
            {
                VrniNti(tab1, 3);
                VrniNti(niz1, -5);
                VrniNti(niz2, -1);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static void VrniNti<T>(T[] tabela, int N) where T : IComparable<T>
        {
            if (N == 0)
            {
                throw new Exception("Tega elementa ni v tabeli. ");
            }
            else if (Math.Abs(N) > tabela.Length)
            {
                throw new Exception("Tega elementa ni v tabeli");
            }
            else if (N > 0)
            {
                Console.WriteLine(tabela[N - 1]);
            }
            else
            {
                Console.WriteLine(tabela[tabela.Length + N]);
            }
        }
    }
}
