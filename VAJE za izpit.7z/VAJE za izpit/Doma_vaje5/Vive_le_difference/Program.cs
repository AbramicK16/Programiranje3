﻿using System;

namespace Vive_le_difference
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program izpiše razliko dveh števil.");
            Console.Write("Zmanjsevanec: ");
            double zmanjsevanec = double.Parse(Console.ReadLine());
            Console.Write("Odstevanec: ");
            double odstevanec = double.Parse(Console.ReadLine());

            try
            {
                Izjeme(zmanjsevanec, odstevanec);
            }
            catch (FormatException)
            {
                Console.WriteLine("Število more biti decimalno, ne celo.");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
        }

        public static void Izjeme(double zmanjsevanec, double odstevanec)
        {
            double razlika = zmanjsevanec - odstevanec;

            if (odstevanec > zmanjsevanec) 
            {
                throw new Exception("Odštevanec mora biti manjši od imenovalca!");
                
            }

            if (zmanjsevanec < 0)
            {
                throw new Exception("Zmanjševanec mora biti nenegativno število");
            }

            if (odstevanec < 0)
            {
                throw new Exception("Odštevanec mora biti nenegativno število");
            }
            else
            {
                Console.WriteLine("Razlika = {0}", razlika);
            }
        }
    }
}
