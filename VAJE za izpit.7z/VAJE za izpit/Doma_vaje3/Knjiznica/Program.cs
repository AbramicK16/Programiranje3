﻿using System;

namespace Knjiznica
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tabela = NakljucnaTabela(5, 17);
            Izpisi("Naključna tabela: ", tabela);
            Console.WriteLine();

            Console.Write("Niz iz tabela: ");
            Console.WriteLine(TabelaKotNiz(tabela));

            string niz = "5 13 7 3 24";
            int[] tab2 = NizKotTabela(niz);
            Izpisi("Tabela, ki jo dobimo iz niza", tab2);
        }

        public static int[] NakljucnaTabela(int d, int m)
        {
            int[] tabela = new int[d]; //tabela dolzine d
            Random random = new Random();
            for(int i = 0; i < d; i++)
            {
                tabela[i] = random.Next(1, m);
            }
            return tabela;
        }

        public static string TabelaKotNiz(int[] t)
        {
            string niz = "";
            for (int i = 0; i < t.Length; i++)
            {
                int el = t[i];
                niz = niz + el + " ";
            }
            return niz;
        }

        public static int[] NizKotTabela(string s)
        {
            char[] locila = { ' ' }; //tabela ločil
            string[] tab = s.Split(locila);
            int[] tabela = new int[tab.Length];
            for (int i = 0; i < tab.Length; i++)
            {
                int el = int.Parse(tab[i]);
                tabela[i] = el;
            }
            return tabela;

        }

        static void Izpisi(string ime, int[] t)
        {
            Console.Write(ime + " ");
            foreach (int el in t)
            {
                Console.Write(el + " ");
            }
        }
    }
}
